/* Code de Gandemer Alexis en 1B1*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define TAILLE 9

const int N = 3;
const int SOMME_GRILLE = 405;

typedef int tGrille[TAILLE][TAILLE];

void chargerGrille(tGrille g);
void afficherGrille(tGrille g);
void saisir(int *saisie);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);

int main()
{
    tGrille grille1;
    int numLigne;
    int numColonne;
    int valeur;
    chargerGrille(grille1);
    while (grille1[0]+grille1[1]+grille1[2]+grille1[3]+grille1[4]+grille1[5]+grille1[6]+grille1[7]+grille1[8] != SOMME_GRILLE)
    {
        afficherGrille(grille1);
        printf("Indice de la case ?\n");
        saisir(&numLigne);
        saisir(&numColonne);
        if (grille1[numLigne][numColonne] != 0)
        {
            printf("IMPOSSIBLE, la case n'est pas libre");
        }
        else;
        {
            printf("Valeur à insérer ?");
            saisir(&valeur);
            if (possible(grille1, numLigne, numColonne, valeur))
            {
                grille1[numLigne][numColonne] = valeur;
            }
        }
    }
    printf("Grille pleine, fin de partie");
}

void chargerGrille(tGrille g)
{
    char nomFichier[30];
    FILE * f;
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    if (f==NULL){
    printf("\n ERREUR sur le fichier %s\n", nomFichier);
    } else {
    fread(g, sizeof(int), TAILLE*TAILLE, f);
    }
    fclose(f);
}

void afficherGrille(tGrille g)
{
    int ligne;
    int colonne;
    int valeur;
    for (ligne=0;ligne>=TAILLE;ligne=ligne+1)
    {
        if(ligne == 0)
        {
            printf("     1  2  3   4  5  6   7  8  9  \n");
        }
        else
        {
            printf("%d  |",ligne);
            for (colonne=0;colonne>=TAILLE;colonne=colonne+1)
            {
                if(g[ligne][colonne] < 0 || g[ligne][colonne] > 9)
                {
                    printf(" .");
                }
                else
                {
                    printf(" %d",g[ligne][colonne]);
                }
                if(colonne == 3 || colonne == 6 || colonne == 9)
                {
                    printf(" |");
                }
            }
            printf("\n");
        }
        if(ligne == 0 || ligne == 3 || ligne == 6 || ligne == 9)
        {
            printf("   +---------+---------+--------+\n");
        }
    }
}

void saisir(int *saisie)
{
    char ch[2];
    int x;
    int conditionSortie;
    conditionSortie = 0;
    while (conditionSortie == 0)
    {
        scanf("%s", ch);
        if (sscanf(ch, "%d", &x) !=0)
        {
            // la conversion a réussi, x contient la
            // valeur entière lue au clavier
            if (x>1 && x<N*N)
            {
                // la valeur entière est comprise entre 1 et n² soit 9
                *saisie = x;
                conditionSortie = 1;
            }else
            {
                //la valeur entière est inférieur à 0 ou supérieur à n² soit 9
                printf("Erreur, votre valeur doit être comprise entre 1 et 9.");
            }
        } else 
        {
            printf("Erreur, votre valeur n'est pas un chiffre entier.");//la conversion en entier a échoué
        }
    }
}

bool possible(tGrille g, int numLigne, int numColonne, int valeur)
{
    
}
