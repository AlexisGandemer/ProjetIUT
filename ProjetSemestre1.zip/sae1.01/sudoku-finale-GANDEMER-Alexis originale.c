/**
 * @file sudoku-final-GANDEMER-Alexis.c
 * @brief Programme de jeu de sudoku sur 10 grilles de bases
 * @author Alexis GANDEMER
 * @version 1.0
 * @date 25/11/23 (version finale) - 19/11/23 (1ère version)
 * 
 * Ce programme charge une grille prédéfini choisi par le joueur, il peut ensuite choisir un numéro de ligne puis un numéro de colonne afin d'entrer une valeur et compléter le sudoku.
 * 
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define TAILLE 9

const int N = 3;
const int SOMME_GRILLE = 405;

typedef int tGrille[TAILLE][TAILLE];

void chargerGrille(tGrille g);
void afficherGrille(tGrille g);
void saisir(int *saisie);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);
int sommegrille(tGrille g);



int main()
{
    tGrille grille1;
    int numLigne;
    int numColonne;
    int valeur;
    chargerGrille(grille1);
    while (sommegrille(grille1) != SOMME_GRILLE) // on sort de la boucle si la somme de toutes les valeurs de la grille est égale à 405
    {
        afficherGrille(grille1);
        printf("Indice de la case ?\n");
        saisir(&numLigne);
        saisir(&numColonne);
        numLigne = numLigne - 1;
        numColonne = numColonne - 1;
        if (grille1[numLigne][numColonne] != 0) // vérifie que la case est libre
        {
            printf("IMPOSSIBLE, la case n'est pas libre");
        }
        else;
        {
            printf("Valeur à insérer ?");
            saisir(&valeur);
            if (possible(grille1, numLigne, numColonne, valeur))
            {
                grille1[numLigne][numColonne] = valeur;
            }
        }
    }
    printf("Grille pleine, fin de partie");
}



void chargerGrille(tGrille g)
/**
 * @brief procedure qui charge un fichier et met ses données dans un tableau 2D
 * @param g de type tGrille, Entrée/Sortie : le réceptacle des données de la grille de sudoku sous forme de tableau 2D
*/
{
    char nomFichier[30];
    FILE * f;
    printf("Nom du fichier ? ");
    scanf("%s", nomFichier);
    f = fopen(nomFichier, "rb");
    if (f==NULL)
    {
        printf("\n ERREUR sur le fichier %s\n", nomFichier);
    } else{
        fread(g, sizeof(int), TAILLE*TAILLE, f);
        fclose(f);
    }

}



void afficherGrille(tGrille g)
/**
 * @brief procédure qui affiche la grille sur le terminale en forme de sudoku
 * @param g de type tGrille, Entrée/Sortie : les données de la grille de sudoku sous forme de tableau 2D
*/
{
    int ligne;
    int colonne;
    for (ligne=0;ligne<=TAILLE;ligne=ligne+1)
    {
        if(ligne == 0)
        {
            // on affiche les coordonées des colonnes de la grille
            printf("     1  2  3   4  5  6   7  8  9  \n");
        }
        else
        {
            // on affiche les coordonées des lignes de la grille et le premier "pipe"
            printf("%d  |",ligne);
            for (colonne=0;colonne<TAILLE;colonne=colonne+1)
            {
                if(g[ligne-1][colonne] < 1 || g[ligne-1][colonne] > 9)
                {
                    // affiche un point si la valeur n'est pas comprise entre 1 et 9
                    printf(" . ");
                }
                else
                {
                    // affiche la valeur si elle est comprise entre 1 et 9
                    printf(" %d ",g[ligne-1][colonne]);
                }
                if(colonne == 2 || colonne == 5 || colonne == 8)
                {
                    // crée en pipe en fin de carée
                    printf("|");
                }
            }
            printf("\n");
        }
        if(ligne == 0 || ligne == 3 || ligne == 6 || ligne == 9)
        {
            printf("   +---------+---------+---------+\n");
        }
    }
}



void saisir(int *saisie)
/**
 * @brief  procédure de saisie d'une valeur dans une case
 * @param  saisie de type int, Sortie : saisie du joueur
*/
{
    char ch[2];
    int valtemp;
    int conditionSortie;
    conditionSortie = 0;
    while (conditionSortie == 0)
    {
        scanf("%s", ch);
        if (sscanf(ch, "%d", &valtemp) !=0)
        {
            // la conversion a réussi, x contient la
            // valeur entière lue au clavier
            if (valtemp >= 1 && valtemp <= N*N)
            {
                // la valeur entière est comprise entre 1 et n² soit 9
                *saisie = valtemp;
                conditionSortie = 1;
            }else
            {
                //la valeur entière est inférieur à 0 ou supérieur à n² soit 9
                printf("Erreur, votre valeur doit être comprise entre 1 et 9.");
            }
        } else 
        {
            //la conversion en entier a échoué
            printf("Erreur, votre valeur n'est pas un chiffre entier.");
        }
    }
}



bool possible(tGrille g, int numLigne, int numColonne, int valeur)
/**
 * @brief  fonction qui vérifie que la valeur donnée peut être placée dans cette case
 * @param  g de type tGrille, Entrée/Sortie : les données de la grille de sudoku sous forme de tableau 2D
 * @param  numLigne de type int, Entrée : le numéro de ligne de la valeur évaluée
 * @param  numColonne de type int, Entrée : le numéro de colonne de la valeur évaluée
 * @param  valeur de type int, Entrée : la valeur entrée par le joueur
 * @return true si la valeur peut être placé, false si elle ne le peut pas
*/
{
    int cpt;
    int cptl;
    int cptc;
    int debutcareel;
    int debutcareec;
    bool resultat;
    bool validecol;
    bool validelig;
    bool validecaree;
    validecol = true;
    validelig = true;
    validecaree = true;
    cpt = 0;
    while (cpt < TAILLE && validecol == true) // sert à parcourir la colonne de notre valeur
    {
        if(g[cpt][numColonne] == valeur)
        {
            validecol = false;
            printf("Erreur! Votre valeur existe déjà dans cette colonne.\n");
        }
        cpt = cpt +1;
    }
    cpt = 0;
    while (cpt < TAILLE && validelig == true) //sert à parcourir la ligne de notre valeur
    {
        if(g[numLigne][cpt] == valeur)
        {
            validelig = false;
            printf("Erreur! Votre valeur existe déjà dans cette ligne.\n");
        }
        cpt = cpt +1;
    }
    cptl = 0; 
    cptc = 0;
    debutcareel = numLigne - numLigne%3; // repère de la coordonée de ligne de la première case du carré
    debutcareec = numColonne - numColonne%3; // repère de la coordonée de colonne de la première case du carré
    while((cptl < N || cptc < N) && validecaree == true)
    {
        for(cptl=0;cptl < N;cptl = cptl + 1)// sert à parcourir le carrée de notre valeur
        {
            if(g[debutcareel+cptl][debutcareec+cptc] == valeur)
                {
                    validecaree = false;
                    printf("Erreur! Votre valeur existe déjà dans ce carée.\n");
                }
        }  
        cptc = cptc + 1;
    }
    if(validelig && validecol && validecaree)
    {
        // tout est validé
        return true;
    }
    else
    {
        // une ou plusieurs conditions ne sont pas validées
        return false;
    }
}

int sommegrille(tGrille g)
/**
 * @brief  fonction qui fait la somme de toutes les valeurs de la grille
 * @param  g de type tGrille, Entrée/Sortie : les données de la grille de sudoku sous forme de tableau 2D
 * @return resultat de type int qui est la somme des valeurs
*/
{
    int resultat;
    int i;
    int j;
    resultat = 0;
    for (i=0;i<TAILLE;i=i+1)
    {
        for(j=0;j<TAILLE;j=j+1)
        {
            resultat = resultat + g[i][j];
        }
    }
    return resultat;
}