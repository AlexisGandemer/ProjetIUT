var indexSectionsWithContent =
{
  0: "acmnpst",
  1: "s",
  2: "acmps",
  3: "ns",
  4: "t",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Variables",
  4: "Définitions de type",
  5: "Macros"
};

