#include <stdio.h>
#include <stdlib.h>

#define TAILLE 9

typedef int tGrille[TAILLE][TAILLE];

void afficherGrille(tGrille g);

int main()
{
    tGrille g = {{},{},{},{},{},{},{},{},{}};
    afficherGrille(g);
}

void afficherGrille(tGrille g)
{
    int ligne;
    int colonne;
    for (ligne=0;ligne<TAILLE;ligne=ligne+1)
    {
        if(ligne == 0)
        {
            printf("     1  2  3   4  5  6   7  8  9  \n");
        }
        else
        {
            printf("%d  |",ligne);
            for (colonne=0;colonne>=TAILLE;colonne=colonne+1)
            {
                if(g[ligne][colonne] < 0 || g[ligne][colonne] > 9)
                {
                    printf(" .");
                }
                else
                {
                    printf(" %d",g[ligne][colonne]);
                }
                if(colonne == 3 || colonne == 6 || colonne == 9)
                {
                    printf(" |");
                }
            }
            printf("\n");
        }
        if(ligne == 0 || ligne == 3 || ligne == 6 || ligne == 9)
        {
            printf("   +---------+---------+--------+\n");
        }
    }
}