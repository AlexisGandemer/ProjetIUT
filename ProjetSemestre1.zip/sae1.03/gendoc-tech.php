<?php
    $lines = file("fichier")

    foreach($lines as $a_line){
        
    }
    

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
	<head>
	    	<meta charset="utf-8" >
	    	<title>Document d'utilisation</title>
	    	<meta name="description" content="Document technique de ..." >
			<meta name="author" content="GANDEMER Alexis">
	</head>
    <body>
        <h1>Documentation utilisateur</h1>
        <hr>

        <h2>En-tête</h2>
        <hr>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, nostrum vel voluptate iste corrupti placeat at odit in explicabo accusamus quibusdam recusandae temporibus earum laborum quae magnam reprehenderit doloremque vitae? Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis dolorum maiores labore animi, accusamus quod quo ab accusantium architecto officia sequi porro aliquam? Repellendus explicabo modi, quibusdam numquam veniam deserunt? Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptates fugiat dicta, atque eveniet odit ullam assumenda voluptas a, cumque officia hic aperiam nesciunt molestias sapiente, dignissimos sit tempora in officiis! Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dicta ratione dolor quasi fugit recusandae, ipsa ipsam dolorum itaque accusamus blanditiis quod laborum quas harum provident sequi nostrum excepturi tempore! Animi? Lorem ipsum dolor, sit amet consectetur adipisicing elit. Temporibus vitae distinctio repudiandae reiciendis, fuga repellat minus nisi, odit voluptatum suscipit, reprehenderit ratione. Eligendi facilis temporibus, sapiente doloribus nam rem esse.</p>

        <h2>Define</h2>
        <hr>
        <ul>
            <li>
                <h4>#define N 3</h4> 
                <ul>
                    <li><em>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nobis, eaque? Magnam incidunt debitis consequuntur nisi, labore aut excepturi et eum error facere hic tenetur optio corrupti quam soluta quo nam?</em></li>
                </ul>
            </li>
            <li>
                <h4>#define TAILLE N*N</h4>
                <ul>
                    <li><em>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora impedit ratione aliquam officia culpa, labore eos numquam fugit facere fuga aspernatur animi soluta sequi, laboriosam suscipit ducimus voluptates ea! Quas!</em></li>
                </ul>
            </li>
        </ul>
        <h2>Structures</h2>
        <hr>

        typedef struct str_etu
        <ul>
            <li><strong>char nom[20]:</strong><em>Lorem ipsum dolor sit amet consectetur adipisicing elit.</em> </li>
            <li><strong>char groupe_td:</strong><em>Lorem ipsum dolor sit amet consectetur adipisicing elit.</em> </li>
            <li><strong>int num_tp:</strong><em>Lorem ipsum dolor sit amet consectetur adipisicing elit.</em> </li>
        </ul>

        <h2>Variables globales</h2>
        <hr>
        <ul>
            <h4>tab grille</h4>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit.</li>
            <h4>int valeur</h4>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit.</li>
        </ul>

        <h2>Fonctions</h2> 
        <hr>

        <h3>void afficherGrille</h3>
        <table>
            <tr>
                <th>Paramètres</th>
                <th>Type</th>
                <th>Commentaire</th>
            </tr>
            <tr>
                <td>grille </td>
                <td>tab</td>
                <td>Lorem ipsum dolor sit amet consectetur adipisicing elit.</td>
            </tr>
            <tr>
                <td>valeur</td>
                <td>entier</td>
                <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</td>
            </tr>
        </table>

        <h3>void chargeGrille</h3>
        <table>
            <tr>
                <th>Paramètres</th>
                <th>Type</th>
                <th>Commentaire</th>
            </tr>
            <tr>
                <td>grille </td>
                <td>tab</td>
                <td>Lorem ipsum dolor sit amet consectetur adipisicing elit.</td>
            </tr>
            <tr>
                <td>valeur</td>
                <td>entier</td>
                <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</td>
            </tr>
        </table>
    </body>
</html>

<?php
    foreach() {
?>
    <li><?php echo  ?></li>
<?php
}
?>