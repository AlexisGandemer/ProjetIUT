#!usr/bin/bash

#Création du volume sae103

docker volume create sae103

#On lance le conteneur clock en l'appelant sae103-forever, on fait aussi en sorte que quand on l'éteint il s'auto-détruit et se détache et on le monte sur le volume sae103

docker container run -d -ti --name sae103-forever --rm -v sae103:/work/ clock

#On copie tous les codes sources en C dans le volume sae103

docker container cp ./*.c sae103-forever:/work/

docker container cp ./config sae103-forever:/work/


#On transforme les fichiers sources .c et .md en HTML

docker container run -v sae103:/work/ sae103-php php gendoc-user.php

#On transforme les fichiers HTML en PDF

docker container run -v sae103:/work/ sae103-html2pdf doc-user-version.html doc-user-version.pdf

docker container run -v sae103:/work/ sae103-html2pdf doc-tech-version.html doc-tech-version.pdf

#On crée l'archive finale

tar czvf feur.tgz /work/

#On copie l'archive vers l'ordinateur physique

docker container cp sae103-forever:/work/*.pdf .

