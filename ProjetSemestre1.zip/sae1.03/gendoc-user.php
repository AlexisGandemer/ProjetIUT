<?php
    $file = "DOC_UTILISATEUR.md";
    fopen($file,'r');
    $lignes = explode('\n',$file);
    while(!feof($file))
    {
        $ligne = fgets($file);
        $valide = true;
        if(str_starts_with($ligne,'####'))
        {
            echo "4";
        }
        else if(str_starts_with($ligne,"###"))
        {
            echo "3";
        }
        else if(str_starts_with($ligne,"##"))
        {
            echo "2";
        }
        else if(str_starts_with($ligne,"#"))
        {
            echo "1";
        }
        /*for($i = 3; $i >= 0;$i += 1)
        {
            if($ligne[$i] == "#")
            {
                $valide = true;
            }
            else
            {
                $valide = false;
            }
            file_put_contents("exemple.html",$ligne);
        }*/
    }
?>

/*<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
	<head>
	    	<meta charset="utf-8" >
	    	<title>Document Utilisateur</title>
	    	<meta name="description" content="Manuel d'utilisation de ..." >
			<meta name="author" content="GANDEMER Alexis">
	</head>
    <body>
        <h1>Lorem Ipsum</h1>

        <h2>Lorem ipsum dolor</h2> 

        <h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>
        
        <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sed metus mollis, lacinia elit id, viverra magna.</h4>
        
        <ul>
            <li>Lorem ipsum</li>
            <li>Lorem ipsum dolor</li>
            <li>feur</li>
        </ul>

        <p>Lorem <i>ipsum dolor sit amet</i>, consectetur adipiscing elit. <strong>Vestibulum sed metus mollis, lacinia elit id</strong>, viverra <strong><i>magna</i></strong></p>


        <p><a href="https://fr.lipsum.com/feed/html">[Lorem Ipsum]</a></p>

        <table>
            <tr>
                <th>Lorem</th>
                <th>Ipsum</th>
                <th>dolor</th>
            </tr>
            <tr>
                <td>lorem</td>
                <td>ipsum</td>
                <td>dolor</td>
            </tr>
            <tr>
                <td>sit</td>
                <td>amet</td>
                <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit</td>
            </tr>
        </table>

        <code>printf("Hello World!\n");</code>

        <pre>
            <code> 
            <p>int main() {
                printf("Hello World!\n");
                return EXIT_SUCCESS;
                }</p>
            </code>
        </pre>
    </body>
</html>*/
