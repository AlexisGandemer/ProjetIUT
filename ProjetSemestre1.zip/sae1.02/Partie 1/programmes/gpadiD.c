#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define N 3
#define TAILLE (N*N)

typedef struct {
    int valeur;
    int candidats[TAILLE];
    int nbCandidats;
} tCase1;

typedef tCase1 tGrille[TAILLE][TAILLE];

void initialiser_candidats(tGrille g);
void ajouterCandidat(tCase1 laCase, int val);
void retirerCandidat(tCase1 laCase, int val);
bool estCandidat(tCase1 laCase, int val);
int nbCandidat(tCase1 laCase);
int chargerGrille(tGrille g);
void afficherGrille(tGrille g);

int main()
{
    tGrille g;
    bool progression;
    int nbCasesVides;
    nbCasesVides = chargerGrille(g);
    printf("Il y a %d cases vides\n", nbCasesVides);
    initialiser_candidats(g);
    progression = true;
    while(nbCasesVides != 0 || progression)
    {
        afficherGrille(g);
        printf("Il y a %d cases vides\n", nbCasesVides);
        progression = false;
        for(int i= 0;i<TAILLE;i++)
        {
            for(int j= 0;j<TAILLE;j++)
            {
                if(nbCandidat(g[i][j]) == 1)
                {
                    int val = 0;
                    val = 0;
                    while(g[i][j].candidats[val] == 0)
                    {
                        val = val + 1;
                    }
                    g[i][j].valeur = g[i][j].candidats[val];
                    g[i][j].nbCandidats = 0;
                    nbCasesVides = nbCasesVides - 1;
                    for(int ligne = 0;i<TAILLE;i++)
                    {
                        for(int cand = 0;cand<TAILLE;cand++)
                        {
                            if (g[ligne][j].candidats[cand] == g[i][j].valeur)
                            {
                                printf("%d",g[ligne][j].nbCandidats);
                                retirerCandidat(g[ligne][j],g[i][j].valeur);
                                printf("%d",g[ligne][j].nbCandidats);
                            }
                        }
                    }
                    for(int colonne = 0;j<TAILLE;j++)
                    {
                        for(int cand = 0;cand<TAILLE;cand++)
                        {
                            if (g[i][colonne].candidats[cand] == g[i][j].valeur)
                            {
                                retirerCandidat(g[i][colonne],g[i][j].valeur);
                            }
                        }
                    }
                    int carrel;
                    int carrec;
                    carrel = i%3;
                    carrec = j%3;
                    for(int cptc=0;cptc < N;cptc = cptc + 1)
                    {
                        for(int cptl=0;cptl < N;cptl = cptl + 1)
                        {
                            for(int cand = 0;cand<TAILLE;cand++)
                            {
                                if(g[carrel+cptl][carrec+cptc].candidats[cand] == g[i][j].valeur)
                                {
                                    retirerCandidat(g[i%3+cptl][j%3+cptc],g[i][j].valeur);
                                }
                            }
                        }
                    }  
                    progression = true;
                }
            }
        }
    }
    
}

void initialiser_candidats(tGrille g)
{
    int i;
    int j;
    int k;
    for(i=0;i<TAILLE;i=i+1)
    {
        for(j=0;j<TAILLE;j=j+1)
        {
            if(g[i][j].valeur != 0)
            {
                g[i][j].nbCandidats = 0;
                for(int ligne = 0;i<TAILLE;i++)
                {
                    for(int cand = 0;cand<TAILLE;cand++)
                    {
                        if (g[ligne][j].candidats[cand] == g[i][j].valeur)
                        {
                            retirerCandidat(g[ligne][j],g[i][j].valeur);
                        }
                    }
                }
                for(int colonne = 0;j<TAILLE;j++)
                {
                    for(int cand = 0;cand<TAILLE;cand++)
                    {
                        if (g[i][colonne].candidats[cand] == g[i][j].valeur)
                        {
                            retirerCandidat(g[i][colonne],g[i][j].valeur);
                        }
                    }
                }
                int carrel;
                int carrec;
                carrel = i%3;
                carrec = j%3;
                for(int cptc=0;cptc < N;cptc = cptc + 1)
                {
                    for(int cptl=0;cptl < N;cptl = cptl + 1)
                    {
                        for(int cand = 0;cand<TAILLE;cand++)
                        {
                            if(g[carrel+cptl][carrec+cptc].candidats[cand] == g[i][j].valeur)
                            {
                                retirerCandidat(g[i%3+cptl][j%3+cptc],g[i][j].valeur);
                            }
                        }
                    }
                }  
            }
            else
            {
                for(k=0;k<TAILLE;k=k+1)
                {
                    g[i][j].candidats[k] = k+1;
                }
                g[i][j].nbCandidats = TAILLE;
            }
        }
    }
}

void ajouterCandidat(tCase1 laCase, int val)
{
    int limiteLaCase;
    limiteLaCase = nbCandidat(laCase);
    laCase.candidats[limiteLaCase+1] = val;
    laCase.nbCandidats = laCase.nbCandidats + 1;
}

void retirerCandidat(tCase1 laCase, int val)
{
    int cpt;
    int limiteLaCase;
    bool valsupprimer;
    cpt = 0;
    limiteLaCase = nbCandidat(laCase);
    valsupprimer = false;
    while(cpt <= limiteLaCase && valsupprimer != true)
    {
        if (val == laCase.candidats[cpt])
        {
            laCase.candidats[cpt] = 0;
            laCase.nbCandidats = laCase.nbCandidats - 1;
            valsupprimer = true;
        }
        else
        {
            cpt = cpt + 1;
        }
    }
}

bool estCandidat(tCase1 laCase, int val)
{
    int cpt;
    int limiteLaCase;
    bool resultat;
    bool valEstCand;
    cpt = 0;
    limiteLaCase = nbCandidat(laCase);
    resultat = false;
    valEstCand = false;
    while(cpt <= limiteLaCase && valEstCand!= true)
    {
        if(val == laCase.candidats[cpt])
        {
            resultat = true;
            valEstCand = true;
        }
        else
        {
            cpt = cpt + 1;
        }
    }
    return resultat;
}

int nbCandidat(tCase1 laCase)
{
    return laCase.nbCandidats;
}

int chargerGrille(tGrille g){
    int nbCasesVides;
    int val;
    char nomFichier[30];
    int i, j;
    nbCasesVides = 0;
    FILE * f;
    do {
        printf("Nom du fichier ? ");
        scanf("%s", nomFichier);
        f = fopen(nomFichier, "rb");
        if (f == NULL) {
            printf("\nERREUR sur le fichier %s. Veuillez recommencer.\n", nomFichier);
        } 
        else {
            for (i=0; i < TAILLE; i++){
                for (j=0; j < TAILLE; j++){
                    fread(&val, sizeof(int), 1, f);
                    g[i][j].valeur = val;
                    if (g[i][j].valeur == 0) {
                        nbCasesVides++;
                    }
                
                }
            }
            fclose(f);
        }
    } while (f == NULL);
    return nbCasesVides;
}

void afficherGrille(tGrille g){
    int i,j;
    printf("   1 2 3   4 5 6   7 8 9 \n");
    printf(" +-------+-------+-------+");
    for (i=0;i<TAILLE;i++){
        printf("\n%d| ",i+1);
        for (j=0;j<TAILLE;j++){
            if (g[i][j].valeur == 0){
                printf(". "); 
            }
            else{
                printf("%d ",g[i][j].valeur);
            }
            if (j%N == 2){printf("| ");}
        }
        if (i%N == 2){printf("\n +-------+-------+-------+");}
    }
    printf("\n");
}
