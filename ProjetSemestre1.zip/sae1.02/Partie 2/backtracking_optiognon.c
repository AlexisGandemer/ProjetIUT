#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define N 4
#define TAILLE (N * N)

typedef struct {
    int valeur;
    bool candidats[TAILLE + 1];
    int nbCandidats;
} tCase2;

typedef tCase2 tGrille[TAILLE][TAILLE];

void initialiser_candidats(tGrille g);
void ajouterCandidat(tCase2 *laCase, int val);
void retirerCandidat(tCase2 *laCase, int val, int i, int j);
bool estCandidat(tCase2 laCase, int val);
int nbCandidat(tCase2 laCase);
bool backtracking(tGrille grille, int numeroCase);
bool possible(tGrille grille, int numLigne, int numColonne, int valeur);
int chargerGrille(tGrille g);
void afficherGrille(tGrille g);

int main()
{
    tGrille g;
    bool progression;
    int nbCasesVides;
    nbCasesVides = chargerGrille(g);
    initialiser_candidats(g);
    progression = true;
    clock_t begin = clock();
    while (nbCasesVides != 0 && progression)
    {
        printf("\nIl y a %d cases vides\n", nbCasesVides);
        afficherGrille(g);
        progression = false;
        for (int i = 0; i < TAILLE; i++)
        {
            for (int j = 0; j < TAILLE; j++)
            {
                if (nbCandidat(g[i][j]) == 1)
                {
                    int val = 1;
                    while (g[i][j].candidats[val] == false)
                    {
                        val = val + 1;
                    }
                    g[i][j].valeur = val;
                    g[i][j].nbCandidats = 0;
                    nbCasesVides = nbCasesVides - 1;
                    for (int ligne = 0; ligne < TAILLE; ligne++)
                    {
                        retirerCandidat(&g[ligne][j], val, i, j);
                    }
                    for (int colonne = 0; colonne < TAILLE; colonne++)
                    {
                        retirerCandidat(&g[i][colonne], val, i, j);
                    }
                    int carrel;
                    int carrec;
                    carrel = i - (i % N);
                    carrec = j - (j % N);
                    for (int cptc = 0; cptc < N; cptc++)
                    {
                        for (int cptl = 0; cptl < N; cptl++)
                        { 
                            retirerCandidat(&g[carrel + cptl][carrec + cptc], val, i, j);
                        }
                    }
                    progression = true;
                }
            }
        }
    }
    backtracking(g,0);
    clock_t end = clock();
    double tmpsCPU = (end - begin)*1.0 / CLOCKS_PER_SEC;
    printf( "Temps CPU = %.3f secondes\n",tmpsCPU);
    printf("\nIl y a %d cases vides\n", nbCasesVides);
    afficherGrille(g);
}

void initialiser_candidats(tGrille g)
{
    int i;
    int j;
    int k;
    int val;
    for (i = 0; i < TAILLE; i++)
    {
        for (j = 0; j < TAILLE; j++)
        {
            if (g[i][j].valeur == 0)
            {
                for (k = 1; k < TAILLE+1; k++)
                {
                    g[i][j].candidats[k] = true;
                }
                g[i][j].nbCandidats = TAILLE;
            }
            else
            {
                for (k = 1; k < TAILLE+1; k++)
                {
                    g[i][j].candidats[k] = false;
                }
                g[i][j].nbCandidats = 0;
            }
        }
    }
    
    for (i = 0; i < TAILLE; i++)
    {
        for (j = 0; j < TAILLE; j++)
        {
            if (g[i][j].valeur == 0)
            {
                for (int ligne = 0; ligne < TAILLE; ligne++)
                {
                    if (g[ligne][j].valeur != 0)
                    {
                        val = g[ligne][j].valeur;
                        retirerCandidat(&g[i][j], val, i, j);
                    }
                }
                for (int colonne = 0; colonne < TAILLE; colonne++)
                {
                    if (g[i][colonne].valeur != 0)
                    {   
                        val = g[i][colonne].valeur;
                        retirerCandidat(&g[i][j], val, i, j);
                    }
                }
                int carrel;
                int carrec;
                carrel = i - (i % N);
                carrec = j - (j % N);
                for (int cptl = 0; cptl < N; cptl++)
                {
                    for (int cptc = 0; cptc < N; cptc++)
                    {
                        if (g[carrel + cptl][carrec + cptc].valeur != 0)
                        {
                            val = g[carrel + cptl][carrec + cptc].valeur;
                            retirerCandidat(&g[i][j], val, i, j);
                        }
                    }
                }
            }
        }
    }
}

void ajouterCandidat(tCase2 *laCase, int val)
{
    laCase->candidats[val] = true;
    laCase->nbCandidats = laCase->nbCandidats + 1;
}

void retirerCandidat(tCase2 *laCase, int val, int i, int j) {
    if (laCase->candidats[val] == true) {
        laCase->candidats[val] = false;
        laCase->nbCandidats = laCase->nbCandidats - 1;
    }
}

bool estCandidat(tCase2 laCase, int val)
{
    int cpt;
    int limiteLaCase;
    bool resultat;
    bool valEstCand;
    cpt = 0;
    limiteLaCase = nbCandidat(laCase);
    resultat = false;
    valEstCand = false;
    while (cpt <= limiteLaCase && valEstCand != true)
    {
        if (laCase.candidats[cpt] == true)
        {
            resultat = true;
            valEstCand = true;
        }
        else
        {
            cpt = cpt + 1;
        }
    }
    return resultat;
}

int nbCandidat(tCase2 laCase)
{
    int cpt = 0;
    for (int i=1; i<TAILLE+1; i++) {
        if (laCase.candidats[i] == true) {
            cpt++;
        }
    }
    return cpt;
}

bool backtracking(tGrille grille, int numeroCase)
{
    int ligne;
    int colonne;
    bool resultat;
    resultat = false;
    if (numeroCase == TAILLE * TAILLE)
    {
        resultat = true;
    }
    else
    {
        ligne = numeroCase / TAILLE;
        colonne = numeroCase % TAILLE;
        if(grille[ligne][colonne].valeur != 0)
        {
            resultat = backtracking(grille, numeroCase+1);
        }
        else
        {
            for(int valeur = 1 ; valeur <= TAILLE ; valeur++)
            {
                if(possible(grille,ligne,colonne,valeur))
                {
                    grille[ligne][colonne].valeur = valeur;
                    
                    if(backtracking(grille,numeroCase+1))
                    {
                        resultat = true;
                    }
                    else
                    {
                        grille[ligne][colonne].valeur = 0;
                    }
                }
            }
        }
    }
    return resultat;
}

bool possible(tGrille grille, int numLigne, int numColonne, int valeur) {
    //Déclaration des variables
    int l, c; // ligne et colonne
    int ligBloc, colBloc; //départ pour traverser un bloc
    bool ligValid, colValid, blocValid, valide;
    ligValid = true;
    colValid = true;
    blocValid = true;
    valide = false;
    l=0; // ligne
    c=0; // colonne
    ligBloc = numLigne; //départ pour parcourir un bloc de 3x3 (verif bloc)
    colBloc = numColonne; //départ pour parcourir un bloc de 3x3 (verif bloc)

    // Check de la ligne
    while ((c < TAILLE) && (ligValid == true)) {
        if (grille[numLigne][c].valeur == valeur) {
            ligValid = false;
            //printf("Erreur: La valeur saisie est déjà présente dans la ligne\n");
        }
        else {
            c = c + 1;
        }
    }

    //Check de la colonne
    while ((l < TAILLE) && (colValid == true)) {
        if (grille[l][numColonne].valeur == valeur) {
            colValid = false;
            //printf("Erreur: La valeur saisie est déjà présente dans la colonne\n");
        }
        else {
            l = l + 1;
        }
    }

    //Check du bloc
    while (ligBloc%N != 0) {
        ligBloc = ligBloc - 1;
    }
    while (colBloc%N != 0) {
        colBloc = colBloc - 1;
    }
    for (int i=ligBloc; i%N<3; i = i + 1) {
        for (int j=colBloc; j%N<3; j = j + 1) {
            if (valeur == grille[i][j].valeur){
                blocValid = false;
                //printf("Erreur: La valeur saisie est déjà présente dans le bloc\n");
            }
        }
    }
    
    //Si les 3 conditions sont remplies, le booléen valide devient vrai
    if ((ligValid == true) && (colValid == true) && (blocValid == true)) {
        valide = true;
    }
    return valide;
}

int chargerGrille(tGrille g)
{
    int nbCasesVides;
    int val;
    char nomFichier[30];
    int i, j;
    nbCasesVides = 0;
    FILE *f;
    do
    {
        printf("Nom du fichier ? ");
        scanf("%s", nomFichier);
        f = fopen(nomFichier, "rb");
        if (f == NULL)
        {
            printf("\nERREUR sur le fichier %s. Veuillez recommencer.\n", nomFichier);
        }
        else
        {
            for (i = 0; i < TAILLE; i++)
            {
                for (j = 0; j < TAILLE; j++)
                {
                    fread(&val, sizeof(int), 1, f);
                    g[i][j].valeur = val;
                    if (g[i][j].valeur == 0)
                    {
                        nbCasesVides++;
                    }
                }
            }
            fclose(f);
        }
    } while (f == NULL);
    return nbCasesVides;
}

void afficherGrille(tGrille g){
    int i,j;
    printf("     1  2  3  4    5  6  7  8     9 10 11 12   13 14 15 16\n");
    printf("   +-------------+-------------+-------------+-------------+");
    for (i=0;i<TAILLE;i++){
        if (i<9) {
            printf("\n%2d | ",i+1);
        }
        else {
            printf("\n%3d| ",i+1);
        }
        for (j=0;j<TAILLE;j++){
            if (g[i][j].valeur == 0){
                printf(" . "); 
            }
            else{
                printf("%2d ",g[i][j].valeur);
            }
            if (j%N == 3){printf("| ");}
        }
        if (i%N == 3){printf("\n   +-------------+-------------+-------------+-------------+");}
    }
    printf("\n");
}