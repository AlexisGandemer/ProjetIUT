#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define N 4
#define TAILLE (N*N)

typedef int tGrille[TAILLE][TAILLE];

bool backtracking(tGrille grille, int numeroCase);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);
int chargerGrille(tGrille g);
void afficherGrille(tGrille g);
bool backtracking(tGrille grille, int numeroCase);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);

int main() {
  tGrille g;
  int nbCasesVides;
  nbCasesVides = chargerGrille(g);
  printf("Il y a %d cases vides\n", nbCasesVides);
  afficherGrille(g);
  backtracking(g, 0);
  afficherGrille(g);
}

bool backtracking(tGrille grille, int numeroCase)
{
    int ligne;
    int colonne;
    bool resultat;
    resultat = false;
    if (numeroCase == TAILLE * TAILLE)
    {
        resultat = true;
    }
    else
    {
        ligne = numeroCase / TAILLE;
        colonne = numeroCase % TAILLE;
        if(grille[ligne][colonne] != 0)
        {
            resultat = backtracking(grille, numeroCase+1);
        }
        else
        {
            for(int valeur = 1 ; valeur <= TAILLE ; valeur++)
            {
                if(possible(grille,ligne,colonne,valeur))
                {
                    grille[ligne][colonne] = valeur;
                    
                    if(backtracking(grille,numeroCase+1))
                    {
                        resultat = true;
                    }
                    else
                    {
                        grille[ligne][colonne] = 0;
                    }
                }
            }
        }
    }
    return resultat;
}

bool possible(tGrille grille, int numLigne, int numColonne, int valeur) {
    //Déclaration des variables
    int l, c; // ligne et colonne
    int ligBloc, colBloc; //départ pour traverser un bloc
    bool ligValid, colValid, blocValid, valide;
    ligValid = true;
    colValid = true;
    blocValid = true;
    valide = false;
    l=0; // ligne
    c=0; // colonne
    ligBloc = numLigne; //départ pour parcourir un bloc de 3x3 (verif bloc)
    colBloc = numColonne; //départ pour parcourir un bloc de 3x3 (verif bloc)

    // Check de la ligne
    while ((c < TAILLE) && (ligValid == true)) {
        if (grille[numLigne][c] == valeur) {
            ligValid = false;
            //printf("Erreur: La valeur saisie est déjà présente dans la ligne\n");
        }
        else {
            c = c + 1;
        }
    }

    //Check de la colonne
    while ((l < TAILLE) && (colValid == true)) {
        if (grille[l][numColonne] == valeur) {
            colValid = false;
            //printf("Erreur: La valeur saisie est déjà présente dans la colonne\n");
        }
        else {
            l = l + 1;
        }
    }

    //Check du bloc
    while (ligBloc%N != 0) {
        ligBloc = ligBloc - 1;
    }
    while (colBloc%N != 0) {
        colBloc = colBloc - 1;
    }
    for (int i=ligBloc; i%N<3; i = i + 1) {
        for (int j=colBloc; j%N<3; j = j + 1) {
            if (valeur == grille[i][j]){
                blocValid = false;
                //printf("Erreur: La valeur saisie est déjà présente dans le bloc\n");
            }
        }
    }
    
    //Si les 3 conditions sont remplies, le booléen valide devient vrai
    if ((ligValid == true) && (colValid == true) && (blocValid == true)) {
        valide = true;
    }
    return valide;
}

int chargerGrille(tGrille g){
    int nbCasesVides;
    int val;
    char nomFichier[30];
    int i, j;
    nbCasesVides = 0;
    FILE * f;
    do {
        printf("Nom du fichier ? ");
        scanf("%s", nomFichier);
        f = fopen(nomFichier, "rb");
        if (f == NULL) {
            printf("\nERREUR sur le fichier %s. Veuillez recommencer.\n", nomFichier);
        } 
        else {
            for (i=0; i < TAILLE; i++){
                for (j=0; j < TAILLE; j++){
                    fread(&val, sizeof(int), 1, f);
                    g[i][j] = val;
                    if (g[i][j] == 0) {
                        nbCasesVides++;
                    }

                }
            }
            fclose(f);
        }
    } while (f == NULL);
    return nbCasesVides;
}

void afficherGrille(tGrille g){
    int i,j;
    printf("     1  2  3  4    5  6  7  8     9 10 11 12   13 14 15 16\n");
    printf("   +-------------+-------------+-------------+-------------+");
    for (i=0;i<TAILLE;i++){
        if (i<9) {
            printf("\n%2d | ",i+1);
        }
        else {
            printf("\n%3d| ",i+1);
        }
        for (j=0;j<TAILLE;j++){
            if (g[i][j] == 0){
                printf(" . "); 
            }
            else{
                printf("%2d ",g[i][j]);
            }
            if (j%N == 3){printf("| ");}
        }
        if (i%N == 3){printf("\n   +-------------+-------------+-------------+-------------+");}
    }
    printf("\n");
}