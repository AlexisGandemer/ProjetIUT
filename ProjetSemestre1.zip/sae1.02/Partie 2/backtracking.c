#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define N 4
#define TAILLE (N*N)

typedef int tGrille[TAILLE][TAILLE];

bool backtracking(tGrille grille, int numeroCase);
bool possible(tGrille g, int numLigne, int numColonne, int valeur);

bool backtracking(tGrille grille, int numeroCase)
{
    int ligne;
    int colonne;
    bool resultat;
    resultat = false;
    if (numeroCase == TAILLE * TAILLE)
    {
        resultat = true;
    }
    else
    {
        ligne = numeroCase / TAILLE;
        colonne = numeroCase % TAILLE;
        if(grille[ligne][colonne] != 0)
        {
            resultat = backtracking(grille, numeroCase+1);
        }
        else
        {
            for(int valeur = 1 ; valeur <= TAILLE ; valeur++)
            {
                if(possible(grille,ligne,colonne,valeur))
                {
                    grille[ligne][colonne] = valeur;
                }

                if(backtracking(grille,numeroCase+1))
                {
                    resultat = true;
                }
                else
                {
                    grille[ligne][colonne] = 0;
                }
            }
        }
    }
    return resultat;
}

bool possible(tGrille g, int numLigne, int numColonne, int valeur)
/**
 * @brief  fonction qui vérifie que la valeur donnée peut être placée dans cette case
 * @param  g de type tGrille, Entrée/Sortie : les données de la grille de sudoku sous forme de tableau 2D
 * @param  numLigne de type int, Entrée : le numéro de ligne de la valeur évaluée
 * @param  numColonne de type int, Entrée : le numéro de colonne de la valeur évaluée
 * @param  valeur de type int, Entrée : la valeur entrée par le joueur
 * @return true si la valeur peut être placé, false si elle ne le peut pas
*/
{
    int cpt;
    int cptl;
    int cptc;
    int debutcareel;
    int debutcareec;
    bool validecol;
    bool validelig;
    bool validecaree;
    validecol = true;
    validelig = true;
    validecaree = true;
    cpt = 0;
    while (cpt < TAILLE && validecol == true) // sert à parcourir la colonne de notre valeur
    {
        if(g[cpt][numColonne] == valeur)
        {
            validecol = false;
            printf("Erreur! Votre valeur existe déjà dans cette colonne.\n");
        }
        cpt = cpt +1;
    }
    cpt = 0;
    while (cpt < TAILLE && validelig == true) //sert à parcourir la ligne de notre valeur
    {
        if(g[numLigne][cpt] == valeur)
        {
            validelig = false;
            printf("Erreur! Votre valeur existe déjà dans cette ligne.\n");
        }
        cpt = cpt +1;
    }
    cptl = 0; 
    cptc = 0;
    debutcareel = numLigne - numLigne%N; // repère de la coordonée de ligne de la première case du carré
    debutcareec = numColonne - numColonne%N; // repère de la coordonée de colonne de la première case du carré
    while((cptl < N || cptc < N) && validecaree == true)
    {
        for(cptl=0;cptl < N;cptl = cptl + 1)// sert à parcourir le carrée de notre valeur
        {
            if(g[debutcareel+cptl][debutcareec+cptc] == valeur)
                {
                    validecaree = false;
                    printf("Erreur! Votre valeur existe déjà dans ce carée.\n");
                }
        }  
        cptc = cptc + 1;
    }
    if(validelig && validecol && validecaree)
    {
        // tout est validé
        return true;
    }
    else
    {
        // une ou plusieurs conditions ne sont pas validées
        return false;
    }

}